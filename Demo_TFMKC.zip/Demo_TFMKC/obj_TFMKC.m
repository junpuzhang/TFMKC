function obj=obj_MKCalphabeta(Hp,H,alpha,beta,set_dm)



end